HOME_IMAGE_PATH = "pictures/start.png"
